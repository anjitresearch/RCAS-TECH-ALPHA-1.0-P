
# CCTNS mock - verify case exists
def verify_case(fir_no, district):
    # In mock, any FIR number starting with 'FIR' is valid
    if not fir_no:
        return False
    return str(fir_no).upper().startswith('FIR')
