
# DigiLocker mock - in real usage, connect via DigiLocker APIs
def fetch_documents(aadhaar_masked):
    return [{'doc_type':'ID', 'status':'AVAILABLE'}]
