
# PFMS mock - simulate disbursement
def disburse_mock(aadhaar_masked, amount):
    # Always succeed in mock
    return {'status':'SUCCESS', 'message': f'Disbursed {amount} to {aadhaar_masked}'}
