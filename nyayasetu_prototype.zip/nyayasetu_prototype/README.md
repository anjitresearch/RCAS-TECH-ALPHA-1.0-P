
# NyayaSetu - Prototype DBT System for PCR/PoA Schemes

This repository contains a lightweight prototype of the "NyayaSetu" solution: a micro web application (Flask) that demonstrates core features for Direct Benefit Transfer (DBT) under PCR/PoA implementation. This prototype is intended for hackathon/demo use and contains stubs/mocks for integrations (Aadhaar, PFMS, CCTNS, DigiLocker).

## What is included
- `backend/` - Flask application with REST APIs for case entry, beneficiary verification, sanctioning & disbursement, tracking, and grievance management.
- `frontend/` - Simple HTML/JS dashboard to interact with the backend.
- `integrations/` - Mock integration modules (aadhaar, pfms, cctns, digilocker).
- `blockchain_ledger.json` - Simple append-only JSON ledger that records disbursement events (simulated blockchain).
- `sample_data/` - Example cases and beneficiaries.
- `run.sh` - Script to create virtualenv, install deps, and run the app (Linux/Mac).
- `requirements.txt` - Python dependencies.

## How to run (quick)
```bash
# from inside the container/environment having Python 3.8+
cd nyayasetu_prototype
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cd backend
export FLASK_APP=app.py
export FLASK_ENV=development
flask run --host=0.0.0.0 --port=5000
# open frontend/index.html in a browser (or use small webserver to serve it)
```

Or run the simple helper:
```bash
./run.sh
```

## Architecture & Notes
- Uses SQLite (file `db.sqlite3`) for simplicity.
- "Blockchain ledger" is a JSON file used to append transactions to ensure immutability for demo purposes.
- Integration modules are mocked: replace with real API connectors in production (Aadhaar, PFMS, DigiLocker, eCourts, CCTNS).
- Security: This is a demo — do NOT use in production without security hardening (Aadhaar use must follow policy and legal constraints).

## Files of interest
- `backend/app.py` - main Flask app & endpoints
- `backend/models.py` - SQLAlchemy models (Case, Beneficiary, Sanction, Grievance)
- `integrations/*` - mocked integration functions
- `frontend/` - minimal UI to trigger flows
