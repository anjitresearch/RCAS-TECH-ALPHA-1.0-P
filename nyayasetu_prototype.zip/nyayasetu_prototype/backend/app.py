
from flask import Flask, request, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os, json
from integrations import aadhaar, pfms, cctns, digilocker

app = Flask(__name__, static_folder='../frontend', static_url_path='/static')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../db.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

from models import Case, Beneficiary, Sanction, Grievance, init_db

LEDGER_FILE = os.path.join(os.path.dirname(__file__), '..', 'blockchain_ledger.json')

@app.route('/api/health')
def health():
    return jsonify({'status':'ok', 'time': datetime.utcnow().isoformat()})

@app.route('/api/cases', methods=['POST'])
def create_case():
    data = request.json
    case = Case(fir_no=data.get('fir_no'), description=data.get('description'), district=data.get('district'), created_at=datetime.utcnow())
    db.session.add(case)
    db.session.commit()
    return jsonify({'case_id': case.id, 'message': 'Case recorded'})

@app.route('/api/beneficiaries', methods=['POST'])
def register_beneficiary():
    data = request.json
    # minimal validation
    ben = Beneficiary(name=data.get('name'), aadhaar_masked=aadhaar.mask_aadhaar(data.get('aadhaar')), phone=data.get('phone'), case_id=data.get('case_id'))
    db.session.add(ben)
    db.session.commit()
    return jsonify({'beneficiary_id': ben.id, 'message': 'Beneficiary registered'})

@app.route('/api/verify_beneficiary/<int:ben_id>', methods=['GET'])
def verify_beneficiary(ben_id):
    ben = Beneficiary.query.get_or_404(ben_id)
    # mock verification using CCTNS + Aadhaar eKYC stub
    case = ben.case
    cctns_ok = cctns.verify_case(case.fir_no, case.district)
    aadhaar_ok = aadhaar.verify_aadhaar_placeholder(ben.aadhaar_masked)
    return jsonify({'beneficiary_id': ben.id, 'name': ben.name, 'aadhaar_verified': aadhaar_ok, 'case_verified': cctns_ok})

@app.route('/api/sanction', methods=['POST'])
def sanction():
    data = request.json
    ben_id = data.get('beneficiary_id')
    amount = data.get('amount', 0)
    ben = Beneficiary.query.get_or_404(ben_id)
    # create sanction entry
    sanction = Sanction(beneficiary_id=ben.id, amount=amount, sanctioned_at=datetime.utcnow(), status='SANCTIONED')
    db.session.add(sanction)
    db.session.commit()
    # write to ledger (simulated blockchain)
    tx = {'type':'SANCTION','sanction_id': sanction.id, 'beneficiary_id': ben.id, 'amount': amount, 'timestamp': sanction.sanctioned_at.isoformat()}
    append_ledger(tx)
    return jsonify({'sanction_id': sanction.id, 'message': 'Sanction created and recorded on ledger'})

@app.route('/api/disburse', methods=['POST'])
def disburse():
    data = request.json
    sanction_id = data.get('sanction_id')
    sanction = Sanction.query.get_or_404(sanction_id)
    ben = sanction.beneficiary
    # call PFMS mock to disburse
    pfms_response = pfms.disburse_mock(ben.aadhaar_masked, sanction.amount)
    sanction.status = 'DISBURSED' if pfms_response.get('status') == 'SUCCESS' else 'FAILED'
    sanction.disbursed_at = datetime.utcnow()
    db.session.commit()
    tx = {'type':'DISBURSE','sanction_id': sanction.id, 'beneficiary_id': ben.id, 'amount': sanction.amount, 'status': sanction.status, 'timestamp': sanction.disbursed_at.isoformat()}
    append_ledger(tx)
    return jsonify({'sanction_id': sanction.id, 'status': sanction.status})

@app.route('/api/track/<int:ben_id>', methods=['GET'])
def track_beneficiary(ben_id):
    ben = Beneficiary.query.get_or_404(ben_id)
    sanctions = [{'id':s.id, 'amount':s.amount, 'status': s.status, 'sanctioned_at': s.sanctioned_at.isoformat() if s.sanctioned_at else None, 'disbursed_at': s.disbursed_at.isoformat() if s.disbursed_at else None} for s in ben.sanctions]
    return jsonify({'beneficiary': {'id':ben.id, 'name':ben.name}, 'sanctions': sanctions})

@app.route('/api/grievance', methods=['POST'])
def lodge_grievance():
    data = request.json
    g = Grievance(beneficiary_id=data.get('beneficiary_id'), message=data.get('message'), created_at=datetime.utcnow(), status='OPEN')
    db.session.add(g)
    db.session.commit()
    return jsonify({'grievance_id': g.id, 'message': 'Grievance lodged'})

@app.route('/api/grievance/<int:gid>', methods=['GET','PUT'])
def grievance_ops(gid):
    g = Grievance.query.get_or_404(gid)
    if request.method == 'PUT':
        data = request.json
        g.status = data.get('status', g.status)
        g.response = data.get('response', g.response)
        db.session.commit()
    return jsonify({'grievance': {'id': g.id, 'beneficiary_id': g.beneficiary_id, 'message': g.message, 'status': g.status, 'response': g.response}})

@app.route('/api/ledger', methods=['GET'])
def get_ledger():
    if os.path.exists(LEDGER_FILE):
        with open(LEDGER_FILE,'r') as f:
            data = json.load(f)
    else:
        data = []
    return jsonify({'ledger': data})

def append_ledger(tx):
    # simple append-only ledger
    if os.path.exists(LEDGER_FILE):
        with open(LEDGER_FILE,'r') as f:
            arr = json.load(f)
    else:
        arr = []
    arr.append(tx)
    with open(LEDGER_FILE,'w') as f:
        json.dump(arr, f, indent=2)

@app.route('/')
def serve_frontend():
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    init_db(app, db)
    app.run(host='0.0.0.0', port=5000, debug=True)
