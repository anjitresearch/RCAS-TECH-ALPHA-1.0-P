
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy.orm import relationship

db = SQLAlchemy()

def init_db(app, db_instance):
    db_instance.init_app(app)
    with app.app_context():
        db_instance.create_all()

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey, Text
from sqlalchemy.orm import relationship
from app import db

class Case(db.Model):
    __tablename__ = 'cases'
    id = Column(Integer, primary_key=True)
    fir_no = Column(String(128), unique=True, nullable=False)
    description = Column(Text)
    district = Column(String(128))
    created_at = Column(DateTime, default=datetime.utcnow)
    beneficiaries = relationship('Beneficiary', backref='case', lazy=True)

class Beneficiary(db.Model):
    __tablename__ = 'beneficiaries'
    id = Column(Integer, primary_key=True)
    name = Column(String(256))
    aadhaar_masked = Column(String(64))
    phone = Column(String(32))
    case_id = Column(Integer, ForeignKey('cases.id'))
    registered_at = Column(DateTime, default=datetime.utcnow)
    sanctions = relationship('Sanction', backref='beneficiary', lazy=True)
    grievances = relationship('Grievance', backref='beneficiary', lazy=True)

class Sanction(db.Model):
    __tablename__ = 'sanctions'
    id = Column(Integer, primary_key=True)
    beneficiary_id = Column(Integer, ForeignKey('beneficiaries.id'))
    amount = Column(Float, default=0.0)
    status = Column(String(64), default='PENDING')
    sanctioned_at = Column(DateTime)
    disbursed_at = Column(DateTime)

class Grievance(db.Model):
    __tablename__ = 'grievances'
    id = Column(Integer, primary_key=True)
    beneficiary_id = Column(Integer, ForeignKey('beneficiaries.id'))
    message = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    status = Column(String(64), default='OPEN')
    response = Column(Text)
